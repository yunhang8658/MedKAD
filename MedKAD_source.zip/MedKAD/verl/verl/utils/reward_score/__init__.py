# Copyright 2024 Bytedance Ltd. and/or its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Reward scoring for the isolated medical Standard OPD runtime."""

from .medical_vqa import reward_func


def default_compute_score(data_source, solution_str, ground_truth, extra_info=None, **kwargs):
    """Fail closed if the explicit medical reward function was not configured."""
    raise RuntimeError(
        "Standard OPD requires custom_reward_function.path pointing to "
        "verl/utils/reward_score/medical_vqa/__init__.py"
    )


__all__ = ["default_compute_score", "reward_func"]
